## database conection
- on git use the #admin_db_connection.php
- local use:
    - $con = new PDO("mysql:host=portfolio.ictcampus.nl;dbname=murcs_budget", "gdb_murcs_budget", "9I0!s3aV");
      $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

## Some exampels
- https://github.com/Programmer-Timmy/Portfolio
